Builders running on the [Corellium](https://corellium.com/)
infrastructure.

The ios and android directories contain scripts and supporting files
for setting up a newly created virtual device.

The current builders run on the https://go.corellium.com account,
kindly provided by [Zenly](https://zen.ly/). Contact: steeve@zen.ly.

New devices are set up through the Corellium
[dashboard](https://go.corellium.com). Stuck devices are reset through
the dashboard as well.
