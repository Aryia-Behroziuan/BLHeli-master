The android-amd64-emu builder is built in two parts:

* first, a large Docker container
* second, a VMX+konlet-based VM image with that Docker image pre-pulled


