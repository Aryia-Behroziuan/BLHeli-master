# golang.org/x/build/cmd/relui

```
               ▀▀█             ▀
  ▄ ▄▄   ▄▄▄     █    ▄   ▄  ▄▄▄
  █▀  ▀ █▀  █    █    █   █    █
  █     █▀▀▀▀    █    █   █    █
  █     ▀█▄▄▀    ▀▄▄  ▀▄▄▀█  ▄▄█▄▄
```

relui is a web interface for managing the release process of Go.
