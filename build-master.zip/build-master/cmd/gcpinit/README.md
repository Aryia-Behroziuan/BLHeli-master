# golang.org/x/build/cmd/gcpinit

The `gcpinit` command is a bootstrapping tool to create resources on
GCP needed by the Go build system.
