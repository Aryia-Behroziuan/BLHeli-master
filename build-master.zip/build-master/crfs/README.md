# CRFS: Container Registry Filesystem

## Moved

This project has moved to https://github.com/google/crfs.

It's more widely applicable than just for use by Go's build system.
