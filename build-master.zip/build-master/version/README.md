# Deprecated.

These are kept for compatibility, but new versions now live in
the "dl" repo: `go get -d golang.org/dl/...` or `git clone https://go.googlesource.com/dl`.
