// Copyright 2016 The Go Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

// The version package permits running a specific version of Go.
//
// Deprecated: Use https://godoc.org/golang.org/dl instead.
package version
